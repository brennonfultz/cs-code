#include <iostream>
#include <fstream>
#include <map>
#include <iomanip>
#include <algorithm>
#include "Header.h"//import required assets
using namespace std;

class Greeter { //user defined class
public:
    Greeter();
    void printGreeting(); //public functions
    
private:
    string greeting; //private members
};
Greeter::Greeter() {
    greeting = "Welcome to the Corner Grocer Produce Sales Database";
}
void Greeter::printGreeting() {
    cout << greeting << endl;
}

int main()
{
    map<string, int> produceItems; //initialize map
    Startup(produceItems); //call startup
    Greeter greeter; 
    greeter.printGreeting(); //greet user 
    DisplayMenu(produceItems); //display menu and pass map to next function

    return 0;
}

