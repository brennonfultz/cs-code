#include <iostream>
#include <map>
#include <fstream>
#include <iomanip>
#include <algorithm>

using namespace std;


void Startup(map<string, int>& dataset) {
	string nextProduceItem;

	ifstream inFS; //open infile
	inFS.open("produceList.txt");
	if (!inFS.is_open()) { //check if file is opened successfully
		cout << "Data file could not be opened.";
		exit(1); //handle file not opened
	}
	while (!inFS.eof()) { //while not at end of file
		inFS >> nextProduceItem; //place data in string
		if (!inFS.fail()) { //check input was successful
			if (dataset.count(nextProduceItem) == 1) { //check if item in map
				dataset.at(nextProduceItem) += 1; //increment count if so
			}
			else {
				dataset.emplace(nextProduceItem, 1); //else add item to map
			}
		}
		else {
			cout << "Error parsing file.";
			exit(1);
		}
	}
	inFS.close();//close infile

	ofstream outFS;
	outFS.open("frequency.dat"); //create output file
	if (!outFS.is_open()) { //check file opened
		cout << "Could not open frequency.dat.";
		exit(1); //handle file not opened
	}
	for (auto& pc : dataset) { //send data to outfile
		outFS << pc.first << " " << pc.second << endl;
	}
	outFS.close();//close outfile
}

void ItemLookup(map<string, int> dataset) {
	string itemToFind;
	string product;
	cout << "Enter item: " << endl; //take input as item name
	cin >> itemToFind;
	transform(itemToFind.begin(), itemToFind.end(), itemToFind.begin(), tolower); //convert to lowercase
	bool match = false; //bool value for item found/not found
	for (const auto &pc : dataset) { //iterate over map with for-in-range loop, pc is product/count
		product = pc.first;
		transform(product.begin(), product.end(), product.begin(), tolower); //convert to lowercase
		if (product == itemToFind) { //if item matches
			cout << pc.second << endl;//print count
			match = true; //set bool to item found
		}
	}
	if (match == false) { //print message if item not found or input invalid
		cout << "No such item found." << endl;
	}
}

void PrintItems(map<string, int> dataset) {
	for (const auto& pc : dataset) { //iterate over map with for-in-range loop, pc is product/count
		cout << pc.first << " " << pc.second << endl;
	}
}

void PrintStars(int numStars){
	for (int i = 0; i < numStars; i++) {
		cout << "*"; //print one star per unit sold
	}
}

void Histogram(map<string, int> dataset) {
	for (const auto& pc : dataset) { //iterate over map with for-in-range loop, pc is product/count
		cout << "\n" << setfill(' ') << setw(15) << pc.first; //set filler/width and print product name
		PrintStars(pc.second); //print count using stars
	}
	cout << "\n";
}

void MenuOption(int selection, map<string, int> dataset) {
	switch (selection) { //switch for each menu option 
	case 1:
		ItemLookup(dataset); //call relevant function per user input
		break;
	case 2:
		PrintItems(dataset);
		break;
	case 3:
		Histogram(dataset);
		break;
	case 4:
		cout << "Closing the program..." << endl;
		exit(0); //program termination
	default:
		cout << "Invalid entry. Please try again." << endl; //input validation
		cin.clear();
		cin.ignore(100, '\n');
		break;
	}
}

void DisplayMenu(map<string, int> dataset) {
	int input; 
	while (true) { //loop until function ends program
		cout << "***Select a menu option:***" << endl;
		cout << "\n[1] Search by item" << endl;
		cout << "[2] View all sales data" << endl;
		cout << "[3] View sales histogram" << endl;
		cout << "[4] Quit" << endl; //display options
		cin >> input; //take input
		MenuOption(input, dataset); //pass input and map to next function
	}
}