#pragma once
#ifndef HEADER_H
#define HEADER_H
using namespace std;

void Startup(map<string, int>& dataset); //declare functions with parameters and return types

void DisplayMenu(map<string, int> dataset);

void MenuOption(int selection, map<string, int> dataset);

void ItemLookup(map<string, int> dataset);

void PrintItems(map<string, int> datset);

void PrintStars(int numStars);

void Histogram(map<string, int> dataset);

#endif
