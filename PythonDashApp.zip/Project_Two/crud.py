from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, user = 'aacuser', password = 'SNHU1234'):
        # Connection Variables
        USER = user
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30254
        DB = 'AAC'
        COL = 'animals'

        # Initialize Connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        if data is not None and isinstance(data, dict):
            inserted = self.collection.insert_one(data)
            return inserted.inserted_id
        else:
            raise Exception("Nothing to save, because data parameter is empty.")

    def read(self, query=None):
        if query is None:
            query = {}
        documents = self.collection.find(query)
        return list(documents)
    
    def update(self, newvalues, query=None, many=False):
        if query is not None and newvalues is not None:
            if many:
                result = self.collection.update_many(query, {"$set": newvalues})
            else:
                result = self.collection.update_one(query, {"$set": newvalues})
            return result.modified_count
        else:
            raise Exception("Incomplete query or values.")
    def delete(self, query, many=False):
        if query is not None:
            if many:
                result = self.collection.delete_many(query)
            else:
                result = self.collection.delete_one(query)
            return result.deleted_count
        else:
            raise Exception("Incomplete query.")
        