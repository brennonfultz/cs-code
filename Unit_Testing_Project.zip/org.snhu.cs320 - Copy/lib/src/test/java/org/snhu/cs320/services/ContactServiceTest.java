package org.snhu.cs320.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Objects;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.snhu.cs320.entities.Contact;

public class ContactServiceTest {
	//tests contact service methods
	ContactService service;
	
	@BeforeEach
	void init() {
		ContactService.INSTANCE = null;
		service = ContactService.getInstance();
		Contact contact1 = new Contact("112233", "Bob", "Smith", "1234567890", "300 Oak Lane");
        Contact contact2 = new Contact("12345", "Bob", "Smith", "1234567890", "300 Oak Lane");
        Contact contact3 = new Contact("123", "Bob", "Smith", "1234567890", "300 Oak Lane");

        service.create(contact1);
        service.create(contact2);
        service.create(contact3);
	}
	
	@Test
    void create_Success() {
        final Contact contact = new Contact("1234567", "Bob", "Smith", "1234567890", "300 Oak Lane");
        service.create(contact);
        assertTrue(service.entityRepository.containsKey("1234567"));
	}
	
	@Test
	public void create_PreventsAddingExistingContact() {
		final Contact c = new Contact("123", "Bob", "Smith", "1234567890", "300 Oak Lane");
		
		assertThrows(Exception.class, () -> service.create(c));
	}
	
	@Test
	public void deleteById_ValidIdIsDeleted() {
		final String id = "123";
        service.deleteById(id);
        assertFalse(service.entityRepository.containsKey(id));
	}
	
	@Test
	public void deleteById_NullInputRejected() {
		assertThrows(NullPointerException.class, () -> service.deleteById(null));
	}
	
	@Test
	public void findById_ValidIdIsFound() {
		final String id = "123";
        Optional<Contact> foundContact = service.findById(id);
        assertEquals("123", foundContact.get().contactId());
	}
	
	@Test
	public void findById_NullInputRejected() {
		assertThrows(NullPointerException.class, () -> service.findById(null));
	}
	
	@Test
	public void update_Success() {
		final String id = "123";
		final Contact newContact = new Contact(id, "Robert", "Smith", "1234567890", "300 Oak Lane");
		Optional<Contact> updated = service.update(newContact);
		assertEquals(newContact, updated.get());
	}
	
	@Test
	public void update_IdNotFound() {
		final String id = "000";
		final Contact newContact = new Contact(id, "Robert", "Smith", "1234567890", "300 Oak Lane");
		assertThrows(IllegalArgumentException.class, () -> service.update(newContact));
	}

}
