package org.snhu.cs320.entities;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import jakarta.validation.Validation;
import jakarta.validation.Validator;

public class ContactTest {
	//test methods for the Contact class
	//testing valid, null, and invalid input for the contact class
	//validator enforces criteria and returns violations to the assertion
	
	    private final Validator validator = Validation.buildDefaultValidatorFactory().getValidator();


	    @Test
	    public void testId_Valid() {
	        assertTrue(validator.validate(new Contact("112233", "Bob", "Smith", "1234567890", "300 Oak Lane")).isEmpty());
	    }

	    @Test
	    public void testId_Null() {
	        assertEquals("ID is required", 
	            validator.validate(new Contact( null, "Bob", "Smith", "1234567890", "300 Oak Lane")).stream().findFirst().get().getMessage());
	    }

	    @Test
	    public void testId_TooLong() {
	        assertEquals("ID cannot be longer than 10 characters",
	            validator.validate(new Contact("112233456789", "Bob", "Smith", "1234567890", "300 Oak Lane")).stream().findFirst().get().getMessage());
	    }

	    @Test
	    public void testFirstName_Valid() {
	        assertTrue(validator.validate(new Contact("112233", "Bob", "Smith", "1234567890", "300 Oak Lane")).isEmpty());
	    }

	    @Test
	    public void testFirstName_Null() {
	        assertEquals("First Name is required", 
	            validator.validate(new Contact("112233", null, "Smith", "1234567890", "300 Oak Lane")).stream().findFirst().get().getMessage());
	    }

	    @Test
	    public void testFirstName_TooLong() {
	        assertEquals("First Name cannot be longer than 10 characters",
	            validator.validate(new Contact("112233", "RobertSmith", "Smith", "1234567890", "300 Oak Lane")).stream().findFirst().get().getMessage());
	    }

	    @Test
	    public void testLastName_Valid() {
	        assertTrue(validator.validate(new Contact("112233", "Bob", "Smith", "1234567890", "300 Oak Lane")).isEmpty());
	    }

	    @Test
	    public void testLastName_Null() {
	        assertEquals("Last Name is required", 
	            validator.validate(new Contact("112233", "Bob", null, "1234567890", "300 Oak Lane")).stream().findFirst().get().getMessage());
	    }

	    @Test
	    public void testLastName_TooLong() {
	        assertEquals("Last Name cannot be longer than 10 characters",
	            validator.validate(new Contact("112233", "Bob", "Smithsonian", "1234567890", "300 Oak Lane")).stream().findFirst().get().getMessage());
	    }

	    @Test
	    public void testPhone_Valid() {
	        assertTrue(validator.validate(new Contact("112233", "Bob", "Smith", "1234567890", "300 Oak Lane")).isEmpty());
	    }

	    @Test
	    public void testPhone_Null() {
	        assertEquals("Phone Number is required", 
	            validator.validate(new Contact("112233", "Bob", "Smith", null, "300 Oak Lane")).stream().findFirst().get().getMessage());
	    }

	    @Test
	    public void testPhone_NonNumericInput() {
	        assertEquals("Phone Number must be 10 digits", 
	            validator.validate(new Contact("112233", "Bob", "Smith", "abc123abc1", "300 Oak Lane")).stream().findFirst().get().getMessage());
	    }

	    @Test
	    public void testPhone_TooLongOrTooShort() {
	        assertEquals("Phone Number must be 10 digits",
	            validator.validate(new Contact("112233", "Bob", "Smith", "1234567", "300 Oak Lane")).stream().findFirst().get().getMessage());
	    }

	    @Test
	    public void testAddress_Valid() {
	        assertTrue(validator.validate(new Contact("112233", "Bob", "Smith", "1234567890", "300 Oak Lane")).isEmpty());
	    }

	    @Test
	    public void testAddress_Null() {
	        assertEquals("Address is required", 
	            validator.validate(new Contact("112233", "Bob", "Smith", "1234567890", null)).stream().findFirst().get().getMessage());
	    }

	    @Test
	    public void testAddress_TooLong() {
	        assertEquals("Address cannot be longer than 30 characters",
	            validator.validate(new Contact("112233", "Bob", "Smith", "1234567890", "300 Oak Lane Southwest Springfield, Nebraska 21844-6719183 last house on the left past the cornfield can't miss it")).stream().findFirst().get().getMessage());
	    }

	
}
