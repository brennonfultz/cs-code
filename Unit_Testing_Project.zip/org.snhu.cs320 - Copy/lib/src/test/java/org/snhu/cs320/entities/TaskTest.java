package org.snhu.cs320.entities;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.snhu.cs320.exceptions.ValidationException;

public class TaskTest {
	
	@Test
	void testSuccessPath() {
		Task task = new Task("1", "Name", "Description");
		assertThat(task)
			.isNotNull()
			.hasFieldOrPropertyWithValue("taskId", "1")
			.hasFieldOrPropertyWithValue("name", "Name")
			.hasFieldOrPropertyWithValue("description", "Description");
	}
	
	@ParameterizedTest
	@CsvSource({
		"'',Name,Description", //blank id
		",Name,Description",	//null id
		"12345678901,Name,Description", //id too long
		"1,,Description", //null name
		"1,'',Description", //blank name
		"1,NameTooLongForThisField,Description", //name too long
		"1,Name,", //null description
		"1,Name,''", //blank description
		"1,Name,DescriptionGreaterThanFiftyCharactersInLengthWhichIsFarTooLong"
	})
	void invalidInputThrowsException(String taskId, String name, String description) {
		assertThatThrownBy(() -> new Task(taskId, name, description))
			.isInstanceOf(ValidationException.class);
	}
	
	
}
