package org.snhu.cs320.entities;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.snhu.cs320.exceptions.ValidationException;

public class TaskServiceTest {
	
	@BeforeEach //test setup
	void init() {
		TaskService.TASK_DATABASE.clear();
	}
	
	@Test
	void addSuccess() { //add method happy path
		Task task = new Task("123", "NameOfTask", "Descript");
		assertThat(TaskService.add(task))
			.isTrue();
		assertThat(TaskService.TASK_DATABASE)
			.containsEntry("123", task);
	}
	
	@Test
	void addExistingId() { //add when id exists
		Task task = new Task("123", "NameOfTask", "Descript");
		assertThat(TaskService.add(task))
			.isTrue();
		assertThat(TaskService.add(task))
		.isFalse();
	}
	
	@Test
	void deleteSuccess() { //delete method happy path
		Task task = new Task("123", "NameOfTask", "Descript");
		assertThat(TaskService.add(task))
			.isTrue();
		assertThat(TaskService.delete("123"))
			.isTrue();
		assertThat(TaskService.TASK_DATABASE).doesNotContainKey("123");
	}
	
	@Test
	void deleteNonExisting() { //delete when id nonexistent
		assertThat(TaskService.delete("123")).isFalse();
	}
	
	@Test
	void updateSuccess() { //update happy path
		Task task = new Task("123", "NameOfTask", "Descript");
		assertThat(TaskService.add(task))
			.isTrue();
		
		Task updated = new Task("123", "NameOfTask", "Description");
		assertThat(TaskService.update("123", updated))
			.isTrue();
		assertThat(TaskService.TASK_DATABASE)
			.extracting("123")
			.hasFieldOrPropertyWithValue("description", "Description");
	}
	
	@Test
	void updateNonExisting() { //update when id nonexistent
		Task updated = new Task("123", "NameOfTask", "Description");
		assertThat(TaskService.update("123", updated))
			.isFalse();
	}
	
	@Test
	void updateThrowsExceptionOnInvalidData() { //update with bad data
		Task task = new Task("123", "NameOfTask", "Descript");
		assertThat(TaskService.add(task))
			.isTrue();
		
		Task updated = new Task("123", "NameOfTask", "Descript");
		updated.setDescription("");
		
		assertThatThrownBy(() -> TaskService.update("123", updated))
			.isInstanceOf(ValidationException.class);
		
	}

}
