package org.snhu.cs320.entities;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {
	
	Date futureDate = new Date((2035 - 1900), 6, 1);
	
	@BeforeEach //test setup
	void init() {
		AppointmentService.APPOINTMENT_DATABASE.clear();
		
	}
	
	@Test
	void addSuccess() { //add method happy path
		Appointment appointment = new Appointment("123", futureDate, "Descript");
		assertThat(AppointmentService.add(appointment))
			.isTrue();
		assertThat(AppointmentService.APPOINTMENT_DATABASE)
			.containsEntry("123", appointment);
	}
	
	@Test
	void addExistingId() { //add when id already exists
		Appointment appointment = new Appointment("123", futureDate, "Descript");
		assertThat(AppointmentService.add(appointment))
			.isTrue();
		assertThat(AppointmentService.add(appointment))
		.isFalse();
	}
	
	@Test
	void deleteSuccess() { //delete method happy path
		Appointment appointment = new Appointment("123", futureDate, "Descript");
		assertThat(AppointmentService.add(appointment))
			.isTrue();
		assertThat(AppointmentService.delete("123"))
			.isTrue();
		assertThat(AppointmentService.APPOINTMENT_DATABASE).doesNotContainKey("123");
	}
	
	@Test
	void deleteNonExisting() { //delete when id nonexistent
		assertThat(AppointmentService.delete("123")).isFalse();
	}

}
