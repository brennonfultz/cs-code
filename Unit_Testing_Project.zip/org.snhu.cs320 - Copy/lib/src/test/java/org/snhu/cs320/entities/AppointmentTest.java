package org.snhu.cs320.entities;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.snhu.cs320.exceptions.ValidationException;

public class AppointmentTest {
	
	Date pastDate = new Date((2020 - 1900), 6, 1);
	Date futureDate = new Date((2035 - 1900), 6, 1);
	

	@Test
	void testSuccessPath() {
		
		
		Appointment appointment = new Appointment("1", futureDate, "Description");
		assertThat(appointment)
			.isNotNull()
			.hasFieldOrPropertyWithValue("appointmentId", "1")
			.hasFieldOrPropertyWithValue("date", futureDate)
			.hasFieldOrPropertyWithValue("description", "Description");
	}
	
	@ParameterizedTest 
	@CsvSource({
		"'',Description", //blank id
		",Description",	//null id
		"12345678901,Description", //id too long
		"1,", //null description
		"1,''", //blank description
		"1,DescriptionGreaterThanFiftyCharactersInLengthWhichIsFarTooLong"//desc too long
	})
	void invalidInputThrowsException(String appointmentId, String description) {
		
		assertThatThrownBy(() -> new Appointment(appointmentId, futureDate, description))
			.isInstanceOf(ValidationException.class);
	}
	
	@Test //dedicated test case for past date
	void pastDateThrowsException() {
		Date pastDate = new Date(2020-1900, 6, 10);
		assertThatThrownBy(() -> new Appointment("1", pastDate, "Description"))
		.isInstanceOf(ValidationException.class);
	}
	
	@Test //dedicated test case for null date
	void nullDateThrowsException() {
		assertThatThrownBy(() -> new Appointment("1", null, "Description"))
		.isInstanceOf(ValidationException.class);
	}

	
	
}
