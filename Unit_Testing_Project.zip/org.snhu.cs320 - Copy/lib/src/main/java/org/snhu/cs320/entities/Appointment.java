package org.snhu.cs320.entities;

import java.util.Date;

import org.snhu.cs320.exceptions.ValidationException;
import org.snhu.cs320.validations.Validation;

public class Appointment {
	
	private String appointmentId;
	private Date date; //created this before I knew LocalDate was allowed
	private String description;
	
	public Appointment (String appointmentId, Date date, String description) throws ValidationException {
		super();
		this.appointmentId = appointmentId;
		this.date = date;
		this.description = description;
		
		validate();
	}
	
	public void validate() throws ValidationException { //validate ID
		Validation.validateNotNull(appointmentId, "ID");
		Validation.validateNotBlank(appointmentId, "ID");
		Validation.validateLength(appointmentId, "ID", 1, 10);
		
		//validate date
		Validation.validateNotNull(date, "Date");
		Validation.validateNotPast(date, "Date");
		
		//validate description
		Validation.validateNotNull(description, "Description");
		Validation.validateNotBlank(description, "Description");
		Validation.validateLength(description, "Description", 1, 50);
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAppointmentId() {
		return appointmentId;
	}
	
	

	
}
