package org.snhu.cs320.entities;

import org.snhu.cs320.exceptions.ValidationException;
import org.snhu.cs320.validations.Validation;

public class Task {
	private String taskId;
	private String name;
	private String description;
	
	public Task(String taskId, String name, String description) {
		super();
		this.taskId = taskId;
		this.name = name;
		this.description = description;
		
		validate();
	}
	
	public void validate() { //validate ID
		Validation.validateNotNull(taskId, "ID");
		Validation.validateNotBlank(taskId, "ID");
		Validation.validateLength(taskId, "ID", 1, 10);
		
		//validate name
		Validation.validateNotNull(name, "Name");
		Validation.validateNotBlank(name, "Name");
		Validation.validateLength(name, "Name", 1, 20);
		
		//validate description
		Validation.validateNotNull(description, "Description");
		Validation.validateNotBlank(description, "Description");
		Validation.validateLength(description, "Description", 1, 50);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTaskId() {
		return taskId;
	}
	
	

}
