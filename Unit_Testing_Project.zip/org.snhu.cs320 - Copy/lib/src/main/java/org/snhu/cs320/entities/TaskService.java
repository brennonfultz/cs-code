package org.snhu.cs320.entities;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class TaskService {
	
	static final Map<String, Task> TASK_DATABASE = new ConcurrentHashMap<String, Task>();
	
	private TaskService() {}
	
	public static boolean add(Task task) {
		if(TASK_DATABASE.containsKey(task.getTaskId())) return false;
		TASK_DATABASE.putIfAbsent(task.getTaskId(), task);
		return true;
	}
	
	public static boolean delete(String taskId) {
		return TASK_DATABASE.remove(taskId) != null;
	}
	
	public static boolean update(String taskId, Task updated) {
		Task existing = TASK_DATABASE.get(taskId);
		
		if(existing == null) return false;
		existing.setName(updated.getName());
		existing.setDescription(updated.getDescription());
		existing.validate();
		
		return true;
		
	}

}
