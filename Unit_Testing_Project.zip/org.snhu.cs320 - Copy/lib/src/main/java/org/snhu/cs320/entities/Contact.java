package org.snhu.cs320.entities;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public record Contact(
		
		//record for storing immutable contact objects
		//validation annotations define the correct inputs
		//these are enforced in the entity validator
		
		@NotNull(message = "ID is required")
		@Size(max = 10, message = "ID cannot be longer than {max} characters")
		String contactId,
		
		@NotNull(message = "First Name is required")
		@Size(max = 10, message = "First Name cannot be longer than {max} characters")
		String firstName,
		
		@NotNull(message = "Last Name is required")
		@Size(max = 10, message = "Last Name cannot be longer than {max} characters")
		String lastName,
		
		@NotNull(message = "Phone Number is required")
		@Pattern(regexp ="\\d{10}", message = "Phone Number must be 10 digits")
		String phone,
		
		@NotNull(message = "Address is required")
		@Size(max = 30, message = "Address cannot be longer than {max} characters")
		String address
) {
}
