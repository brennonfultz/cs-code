package org.snhu.cs320.entities;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class AppointmentService {
	
	static final Map<String, Appointment> APPOINTMENT_DATABASE = new ConcurrentHashMap<String, Appointment>();
	
	private AppointmentService() {}
	
	public static boolean add(Appointment appointment) {
		if(APPOINTMENT_DATABASE.containsKey(appointment.getAppointmentId())) return false;
		APPOINTMENT_DATABASE.putIfAbsent(appointment.getAppointmentId(), appointment);
		return true;
	}
	
	public static boolean delete(String appointmentId) {
		return APPOINTMENT_DATABASE.remove(appointmentId) != null;
	}
	
}
